package com.pages.RLL_240Testing_BooksWagon_PersonalSettings;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Login {

	WebDriver driver;
    By MyAccount = By.xpath("//span[contains(text(),'My Account')]");
    By loginButton = By.xpath("//div[@id='ctl00_divLogin']/a[@href='https://www.bookswagon.com/login']");
    By emailField = By.xpath("//input[@id='ctl00_phBody_SignIn_txtEmail']");
    By passwordField = By.xpath("//input[@id='ctl00_phBody_SignIn_txtPassword']");
    By submitButton = By.xpath("//a[@id='ctl00_phBody_SignIn_btnLogin']");
    By wishlistIcon = By.xpath("//label[@id='ctl00_lblWishlistCount']");
    
    public Login(WebDriver driver) {
        this.driver = driver;
    }
    public void launchBooksWagon() {
        driver.get("https://www.bookswagon.com/");
        driver.manage().window().maximize();
    }
    

    public void login(String username, String password) throws InterruptedException {
        WebElement profileIcon = driver.findElement(MyAccount);
        // Click on the profile icon
        Actions actions = new Actions(driver);
        actions.moveToElement(profileIcon).perform();
        Thread.sleep(1000);
        WebElement Logint = driver.findElement(loginButton);
        Logint.click();
        // Enter username and password
        WebElement usernameField = driver.findElement(emailField);
        usernameField.sendKeys(username);
        WebElement passwordInput = driver.findElement(passwordField);
        passwordInput.sendKeys(password);
        Thread.sleep(1000);
        // Click the login button
        WebElement loginButton = driver.findElement(submitButton);
        loginButton.click();
}
}
	
	/*WebDriver driver;
	 
    By MyAccount=By.xpath("//span[contains(text(),\"My Account\")]");
    By loginButton = By.xpath("//h3[contains(text(),\"Log in\")]");
    By emailField = By.xpath("//input[@id=\"ctl00_phBody_SignIn_txtEmail\"]");
    By passwordField = By.xpath("//input[@id=\"ctl00_phBody_SignIn_txtPassword\"]");
    By submitButton = By.xpath("//a[@id=\"ctl00_phBody_SignIn_btnLogin\"]");


    public Login (WebDriver driver)  {
                    this.driver = driver;      
    }
    public void enter_emailfield(String lgn_mobile) throws InterruptedException {
                    driver.findElement(emailField).sendKeys(lgn_mobile);
                    Thread.sleep(1000);
    }
    public void enter_password(String password) throws InterruptedException {
                    driver.findElement(passwordField).sendKeys(password);
                    Thread.sleep(1000);
    }
    public void click_submitButtton() {
                    driver.findElement(submitButton).click();
    }
}*/
