package com.pages.RLL_240Testing_BooksWagon_PersonalSettings;

import java.time.Duration;

//import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;


public class PersonalSetting {

	/*WebDriver driver;
	Login l;
		//By MyAccount=By.xpath("//span[contains(text(),\"My Account\")]");
		By MyAccount=By.xpath("//*[@id=\"ctl00_lblUser\"]");
		By yourAccount = By.xpath("//a[contains(text(),\"Your Account\")]");
		//By perssett = By.xpath("//*[@href=\"accountsetting.aspx\"]");
		By perssett = By.xpath("//*[@id=\"site-wrapper\"]/div/div/div/div/div/div[1]/div/a");

		public PersonalSetting(WebDriver driver)  {
			this.driver = driver;
			l = new Login(driver);
		}

		public void launch() throws InterruptedException {
			driver.get("https://www.bookswagon.com/myaccount.aspx");
		//l.login("7660830781","Sravani@123");

		}
		public void click_myAccount() {
			driver.findElement(MyAccount).click();
		}
		public void click_yourAccount() throws InterruptedException {
			driver.findElement(yourAccount).click();
//			   WebElement personalsetting = driver.findElement(perssett);
//			    Actions actions = new Actions(driver);
//			    actions.moveToElement(personalsetting).perform();
//			   Thread.sleep(1000);
//			     personalsetting.click();
		}
		public void click_personalSettingsButton() throws InterruptedException {


			driver.findElement(perssett).click();
		}



	}*/

	WebDriver driver;
	//By MyAccount=By.xpath("//span[contains(text(),\"My Account\")]");
	By perssett =By.xpath("//*[@id=\"site-wrapper\"]/div/div/div/div/div/div[1]/div/a");
	//By perssett = By.xpath("//*[@id=\"site-wrapper\"]/div/div/div/div/div/div[1]/div/a");

	public PersonalSetting(WebDriver driver)  {
		this.driver = driver;
	}
	//		public void click_myAccount() {
	//			driver.findElement(MyAccount).click();
	//		}
	public void launch() {
		//driver.get("https://www.bookswagon.com/myaccount.aspx");
		driver.get("https://www.bookswagon.com/");
		//driver.navigate().to("https://www.bookswagon.com/accountsetting.aspx");
		
	}
	public void click_personalSettingsButton() {
		

		driver.findElement(perssett).click();
	}
}



/*src="/images/personalsetttingicon.jpg"*/
