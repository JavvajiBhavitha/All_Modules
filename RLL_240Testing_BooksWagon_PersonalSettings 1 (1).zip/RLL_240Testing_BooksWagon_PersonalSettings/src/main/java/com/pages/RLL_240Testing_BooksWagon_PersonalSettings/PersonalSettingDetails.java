package com.pages.RLL_240Testing_BooksWagon_PersonalSettings;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PersonalSettingDetails {

	/*WebDriver driver;
	Select select;
	By fn = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtfname");
	By ln =By.name("ctl00$phBody$AccountSetting$fvCustomer$txtLName");
	By em = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtemail");
	By fx =By.name("ctl00$phBody$AccountSetting$fvCustomer$txtFax");
	By pn =By.name("ctl00$phBody$AccountSetting$fvCustomer$txtProfileName");
	By IsPublicWishlist =By.xpath("//select[@id=\"ctl00_phBody_AccountSetting_fvCustomer_ddlWishlist\"]");
	By NewsletterSubscription = By.xpath("//select[@id=\"ctl00_phBody_AccountSetting_fvCustomer_chkNewsletter\"]");
	By transmailUnsubscribe =By.xpath("//select[@id=\"ctl00_phBody_AccountSetting_fvCustomer_chkTransUnsubscribe\"]");
	By promomailUnsubscribe = By.xpath("//select[@id=\"ctl00_phBody_AccountSetting_fvCustomer_chkPromoUnsubscribe\"]");
	By YourPublicWishlistURL =By.xpath("//a[@href=\"https://www.bookswagon.com/wishlist/Sravani\"]");
	By countryCode = By.xpath("//select[@id=\"ctl00_phBody_AccountSetting_fvCustomer_ddlCountryCode\"]");
	By mobile =By.xpath("//input[@id=\"ctl00_phBody_AccountSetting_fvCustomer_txtMobile\"]");
	By checkbox =By.xpath(("(//div[@role=\"presentation\"])[1]"));
	By Updatebutton = By.xpath("//input[@id=\"ctl00_phBody_AccountSetting_fvCustomer_imgUpdate\"]"); 
	By cancelButton = By.xpath("//input[@id=\"lnkbtnCancel\"]");
    By enterOTP = By.xpath("//input[@id=\"ctl00_phBody_AccountSetting_fvCustomer_txtEmailOTP\"]");
	By verifyOTP = By.xpath("//input[@id=\"ctl00_phBody_AccountSetting_fvCustomer_btnOTP\"]");

	public PersonalSettingDetails(WebDriver driver)  {
		this.driver = driver;
	}
	public void launch()  {
		driver.get("https://www.bookswagon.com/accountsetting.aspx");
	}
	public void enter_firstname(String first_name ) {
		driver.findElement(fn).clear();
		driver.findElement(fn).sendKeys(first_name);
	}
	public void enter_lastname(String last_name ) {
		driver.findElement(ln).clear();
		driver.findElement(ln).sendKeys(last_name);
	}
	public void enter_email(String email ) {
		driver.findElement(em).clear();
		driver.findElement(em).sendKeys(email);
	}
	public void enter_fax(String fax ) {
		driver.findElement(fx).clear();
		driver.findElement(fx).sendKeys(fax);
	}
	public void enter_profileName(String profile_name) {
		driver.findElement(pn).clear();
		driver.findElement(pn).sendKeys(profile_name);
	}
	public void select_IsPublicWishlist() throws InterruptedException {
		driver.findElement(IsPublicWishlist).click();
		WebElement dropdown = driver.findElement(IsPublicWishlist);
		select = new Select(dropdown);
		select.selectByValue("False");
		Thread.sleep(2000);
	}
	public void select_NewsletterSubscription() throws InterruptedException {
		driver.findElement( NewsletterSubscription).click();
		 WebElement dropdown1 = driver.findElement( NewsletterSubscription);
			select = new Select(dropdown1);
			select.selectByValue("False");
			Thread.sleep(2000);
	}
	public void select_transmailUnsubscribe () throws InterruptedException {
		driver.findElement(transmailUnsubscribe).click();
		WebElement dropdown2 = driver.findElement(transmailUnsubscribe);
		select = new Select(dropdown2);
		select.selectByValue("False");
		Thread.sleep(2000);
	}
	public void select_promomailUnsubscribe() throws InterruptedException {
	driver.findElement(promomailUnsubscribe).click();
	WebElement dropdown3 = driver.findElement( promomailUnsubscribe);
	select = new Select(dropdown3);
	select.selectByValue("False");
	Thread.sleep(2000);
	}
	public void select_countryCode() throws InterruptedException {
		driver.findElement(countryCode).click();
		WebElement dropdown4 = driver.findElement(countryCode);
		select = new Select(dropdown4);
		select.selectByValue("IN +91");
		driver.findElement(countryCode).click();
		Thread.sleep(2000);
	}
	public void enter_mobileNumber(String mobile_number) throws InterruptedException {
		driver.findElement(mobile).clear();
		driver.findElement(mobile).sendKeys(mobile_number);
		WebElement targetElement = driver.findElement(By.xpath("//input[@id=\"ctl00_phBody_AccountSetting_fvCustomer_imgUpdate\"]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", targetElement);
        Thread.sleep(30000);
        targetElement.click();
		Thread.sleep(2000);
	}
	public void click_checkBox() throws InterruptedException {
		driver.findElement(checkbox).click();
		Thread.sleep(2000);
	}
	public void click_updateButton() throws InterruptedException {
	    driver.findElement(Updatebutton).click();
	    Thread.sleep(2000);
	}
	public void enter_OTP() throws InterruptedException {
		driver.findElement(enterOTP).click();
		Thread.sleep(5000);
	}
	public void verify_OTP() throws InterruptedException {
		driver.findElement(verifyOTP).click();
		Thread.sleep(2000);
	}
	public void click_checkBox1() throws InterruptedException {
	    driver.findElement(checkbox).click();
	    Thread.sleep(2000);
    }
	public void click_updateButton1() throws InterruptedException {
		driver.findElement(Updatebutton).click();
	    Thread.sleep(2000);
 
	}


}*/


	
	
	    private WebDriver driver;
	    private WebDriverWait wait;
	    private Select select;

	    private By fn = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtfname");
	    private By ln = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtLName");
	    private By em = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtemail");
	    private By fx = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtFax");
	    private By pn = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtProfileName");
	    private By IsPublicWishlist = By.id("ctl00_phBody_AccountSetting_fvCustomer_ddlWishlist");
	    private By NewsletterSubscription = By.id("ctl00_phBody_AccountSetting_fvCustomer_chkNewsletter");
	    private By transmailUnsubscribe = By.id("ctl00_phBody_AccountSetting_fvCustomer_chkTransUnsubscribe");
	    private By promomailUnsubscribe = By.id("ctl00_phBody_AccountSetting_fvCustomer_chkPromoUnsubscribe");
		private By countryCode = By.xpath("//select[@id=\"ctl00_phBody_AccountSetting_fvCustomer_ddlCountryCode\"]");

	    private By mobile = By.id("ctl00_phBody_AccountSetting_fvCustomer_txtMobile");
	    private By checkbox = By.xpath("(//div[@role='presentation'])[1]");
	    private By updateButton = By.id("ctl00_phBody_AccountSetting_fvCustomer_imgUpdate");
	    private By enterOTP = By.id("ctl00_phBody_AccountSetting_fvCustomer_txtEmailOTP");
	    private By verifyOTP = By.id("ctl00_phBody_AccountSetting_fvCustomer_btnOTP");
		private String value;

	    public PersonalSettingDetails(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    }

	    public void launch() {
	        driver.get("https://www.bookswagon.com/accountsetting.aspx");
	    }

	    private void waitForElementToBeVisible(By locator) {
	        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	    }

	    private void waitForElementToBeClickable(By locator) {
	        wait.until(ExpectedConditions.elementToBeClickable(locator));
	    }

	    public void enter_firstname(String first_name) {
	    	waitForElementToBeVisible(fn);
	    	WebElement firstNameField = driver.findElement(fn);
	        driver.findElement(fn).clear();
	        driver.findElement(fn).sendKeys(first_name);
	    }

	    public void enter_lastname(String last_name) {
	    	waitForElementToBeVisible(ln);
	    	WebElement firstNameField = driver.findElement(ln);
	        driver.findElement(ln).clear();
	        driver.findElement(ln).sendKeys(last_name);
	    }

	    public void enter_email(String email) {
	    	 waitForElementToBeVisible(em);
	         WebElement emailField = driver.findElement(em);
	        driver.findElement(em).clear();
	        driver.findElement(em).sendKeys(email);
	    }

	    public void enter_fax(String fax) {
	    	 waitForElementToBeVisible(fx);
	         WebElement faxField = driver.findElement(fx);
	        driver.findElement(fx).clear();
	        driver.findElement(fx).sendKeys(fax);
	    }

	    public void enter_profileName(String profile_name) {
	    	 waitForElementToBeVisible(pn);
	         WebElement profileNameField = driver.findElement(pn);
	        driver.findElement(pn).clear();
	        driver.findElement(pn).sendKeys(profile_name);
	    }

	    public void select_IsPublicWishlist(String value) {
	    	waitForElementToBeVisible(IsPublicWishlist);
	        select = new Select(driver.findElement(IsPublicWishlist));
	        select.selectByValue(value);
	    }

	    public void select_NewsletterSubscription(String value) {
	    	waitForElementToBeVisible(NewsletterSubscription);
	        select = new Select(driver.findElement(NewsletterSubscription));
	        select.selectByValue(value);
	    }

	    public void select_transmailUnsubscribe(String value) {
	    	 waitForElementToBeVisible(transmailUnsubscribe);
	        select = new Select(driver.findElement(transmailUnsubscribe));
	        select.selectByValue(value);
	    }

	    public void select_promomailUnsubscribe(String value) {
	    	 waitForElementToBeVisible(promomailUnsubscribe);
	        select = new Select(driver.findElement(promomailUnsubscribe));
	        select.selectByValue(value);
	    }
	    
	    public void select_countryCode() throws InterruptedException {
			
	    	 waitForElementToBeVisible(countryCode);
			select = new Select(driver.findElement(countryCode));
			select.selectByValue(value);
			
		}

	    public void enter_mobileNumber(String mobile_number) {
	    	 waitForElementToBeVisible(mobile);
	         WebElement mobileField = driver.findElement(mobile);
	        driver.findElement(mobile).clear();
	        driver.findElement(mobile).sendKeys(mobile_number);
	    }

	    public void click_checkBox() {
	    	 waitForElementToBeClickable(checkbox);
	        driver.findElement(checkbox).click();
	    }

	    public void click_updateButton() {
	    	 waitForElementToBeClickable(updateButton);
	        driver.findElement(updateButton).click();
	    }

	    public void enter_OTP(String otp) {
	    	waitForElementToBeVisible(enterOTP);
	        WebElement otpField = driver.findElement(enterOTP);
	        driver.findElement(enterOTP).clear();
	        driver.findElement(enterOTP).sendKeys(otp);
	    }

	    public void verify_OTP() {
	    	  waitForElementToBeClickable(verifyOTP);
	          driver.findElement(verifyOTP).click();
	        
	    }
	}





