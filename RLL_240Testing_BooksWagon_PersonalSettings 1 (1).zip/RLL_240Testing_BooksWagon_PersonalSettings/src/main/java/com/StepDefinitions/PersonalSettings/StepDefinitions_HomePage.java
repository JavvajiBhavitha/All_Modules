package com.StepDefinitions.PersonalSettings;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.HomePage;


import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class StepDefinitions_HomePage {

	WebDriver driver;
    HomePage hp;
    Logger log11;
   
    
    @Before
    public void init() {
                    driver = new ChromeDriver();
                    hp = new HomePage(driver);
                    log11=Logger.getLogger(StepDefinitions_HomePage.class);
                   
                    
    }
    
    @Given ("user should be in home page")
    public void user_should_be_in_home_page() {
                    hp.launch();

    }
    @When ("user click on my account")
    public void user_click_on_my_account() {
                    hp.Click_MyAccount();
                    log11.info("user is in my account");

    }
    @Then ("user should be navigated to the My Account page")
    public void user_should_be_navigated_to_the_My_Account_page() {
                    String expectedUrl = "https://www.bookswagon.com/myaccount";
                    String actualUrl = driver.getCurrentUrl();
                    
         //Assert.assertEquals(actualUrl, expectedUrl, "User is not navigated to the My Account page");
    }
}

