package com.StepDefinitions.PersonalSettings;



import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.HomePage;
import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.Login;

import dev.failsafe.internal.util.Assert;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions_Login {

	WebDriver driver;
    Login ln;
    HomePage hp;
    Logger log12;

   /* @Before
	public void init() {
		driver = new ChromeDriver();
		hp=new HomePage(driver);
		 ln= new Login(driver);
		 log12 = Logger.getLogger(StepDefinitions_Login.class);
	}*/
    @Given("the user launches the BooksWagon website")
    public void the_user_launches_the_BooksWagon_website() {
        // Initialize the WebDriver
       // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        ln = new Login(driver);
        log12 =Logger.getLogger(StepDefinitions_Login.class); 
        ln.launchBooksWagon();
    }

    @When("the user logs in with username {string} and password {string}")
    public void the_user_logs_in_with_username_and_password(String username, String password) throws InterruptedException {
        ln.login(username, password);
        log12.info("user logs in with username and password");
    }


     @Then("the user should be logged in successfully")
    public void the_user_should_be_logged_in_successfully() {
       
    }

	
     }
	
	 /* WebDriver driver;
      Login ln;
      
      @Before
      public void init() {
                      driver = new ChromeDriver();
                      ln = new Login(driver);
      }
      

      @Given("user in Login page")
      public void user_in_login_page() throws InterruptedException {
         
      }

      @When("User Enters login_mobileno <lgn_mobile> {string}")
      public void user_enters_login_mobileno(String lgn_mobile) throws InterruptedException {
                      ln.enter_emailfield(lgn_mobile);
      }

      @When("User Enters Password {string}")
      public void user_enters_password(String password) throws InterruptedException {
                      ln.enter_password(password);
      }
      @When("User clicks on Login_button")
      public void user_clicks_on_login_button() throws InterruptedException {
                      ln.click_submitButtton();
      }

      @Then("User can login successfully")
      public void user_can_login_successfully() {
//                       String expected = "My Account";
//                          WebElement actualElement = driver.findElement(By.xpath("//*[contains(text(),\"My Account\")]"));
//                          String actualText = actualElement.getText();
//                         
//                          Assert.assertEquals(actualText, expected);
//                         
//                          if (actualText.equals(expected)) {
//                              System.err.println("User logged in Successfully");
//                          } else {
//                              System.out.println("Invalid Credentials");
//                          }
      }
}
*/

