package com.StepDefinitions.PersonalSettings;

import org.apache.log4j.Logger;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.HomePage;
import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.Login;
import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.PersonalSettingDetails;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions_PersonalSettingDetails {

	/*WebDriver driver;
	HomePage hp;
	Login ln;
	PersonalSettingDetails psd;
	Logger log14;
	
 
	@Before
	public void init() {
		driver = new ChromeDriver();
		psd = new PersonalSettingDetails(driver);
		hp=new HomePage(driver);
		ln = new Login(driver);
		log14 = Logger.getLogger(StepDefinitions_PersonalSettingDetails.class);
	}
	 @Given("User is on personal details page1")
	    public void user_is_on_personal_details_page1() throws InterruptedException  {
	    	 psd.launch();
	    	 Thread.sleep(1000);
	 		ln.login("7660830781","Sravani@123");
	 		Thread.sleep(1000);
            
	    	 log14.info("User is in personal details page");
	    }
 
	    @When("^User enters first name (.*)$")
	    public void user_enters_first_name(String first_name) {
	       psd.enter_firstname(first_name);
	    }
 
	    @When("^User enters last name (.*)$")
	    public void user_enters_last_name(String last_name) {
	        psd.enter_lastname(last_name);
	    }
 
	    @When("^User enters email (.*)$")
	   public void user_enters_email(String email) {
	    	psd.enter_email(email);
	    }
	    @When("^User enters fax  (.*)$")
	    public void user_enters_fax(String fax) {
	       psd.enter_fax(fax);
	    }
 
	    @When("^User enters profile name (.*)$")
	    public void user_enters_profile_name(String profile_name) {
	        psd.enter_profileName(profile_name);
	    }
 
	    @When("User selects the option in Is Public Wishlist {string}")
	    public void user_selects_the_option_in_is_public_wishlist(String is_public_wishlist) throws InterruptedException {
	    	psd.select_IsPublicWishlist();
	       	    }
	    @When("User selects the option in Is Newsletter Subscription {string}")
	    public void user_selects_the_option_in_is_newsletter_subscription(String newsletter_subscription) throws InterruptedException {
	      psd.select_NewsletterSubscription();
	    }
 
	    @When("User selects the option in Is Transmail Unsubscribe {string}")
	    public void user_selects_the_option_in_is_transmail_unsubscribe(String transmail_unsubscribe) throws InterruptedException {
	       psd.select_transmailUnsubscribe();
	    }
 
	    @When("User selects the option in Is Promomail Unsubscribe {string}")
	    public void user_selects_the_option_in_is_promomail_unsubscribe(String promomail_unsubscribe) throws InterruptedException {
	       psd.select_promomailUnsubscribe();
	    }
 
	    @When("^User enters mobile number (.*)$")
	    public void user_enters_mobile_number(String mobile_number) throws InterruptedException {
	        psd.enter_mobileNumber(mobile_number);
	    }
 
	    @When("User clicks on the I am not a robot checkbox")
	    public void user_clicks_on_the_i_am_not_a_robot_checkbox() throws InterruptedException {
	      psd.click_checkBox();
	    }
 
	    @When("User clicks on the Update button1")
	    public void user_clicks_on_the_update_button1() throws InterruptedException {
	      psd.click_updateButton();
	    }
 
	    @When("^User enters the email OTP (.*)$")
	    public void user_enters_the_email_otp(String OTP) throws InterruptedException {
	      psd.enter_OTP();
	    }
 
	    @When("User clicks on the Verify button")
	    public void user_clicks_on_the_verify_button() throws InterruptedException {
	       psd.verify_OTP();
	    }
 
	    @When("User clicks on the Update button again")
	    public void user_clicks_on_the_update_button_again() throws InterruptedException {
	       psd.click_updateButton();
	    }
 
	    @Then("User should be able to update the personal details successfully")
	    public void user_should_be_able_to_update_the_personal_details_successfully() {
//	       String expected = "My Account";
//	        WebElement actualElement = driver.findElement(By.xpath("//*[contains(text(),\"My Account\")]"));
//		    String actualText = actualElement.getText();
		   /* Assert.assertEquals(actualText, expected);
		    if (actualText.equals(expected)) {
		        System.err.println("Personal details updated successfully");
		    } else {
		        System.out.println("Update Unsuccessfull");
		    }
		    System.out.println("personalsetting details");
	}
}*/
	
	
	
	
	    private WebDriver driver;
	    private HomePage hp;
	    private Login ln;
	    private PersonalSettingDetails psd;
	    private Logger log;

	    @Before
	    public void init() {
	        driver = new ChromeDriver();
	        psd = new PersonalSettingDetails(driver);
	        hp = new HomePage(driver);
	        ln = new Login(driver);
	        log = Logger.getLogger(StepDefinitions_PersonalSettingDetails.class);
	    }

	    @Given("User is on personal details page")
	    public void user_is_on_personal_details_page() throws InterruptedException {
	        psd.launch();
	        Thread.sleep(1000); // Use WebDriverWait instead for better practice
	        ln.login("7660830781", "Sravani@123");
	        Thread.sleep(1000);
	        log.info("User is on personal details page.");
	    }

	    @When("^User enters first name (.*)$")
	    public void user_enters_first_name(String first_name) {
	        psd.enter_firstname(first_name);
	    }

	    @When("^User enters last name (.*)$")
	    public void user_enters_last_name(String last_name) {
	        psd.enter_lastname(last_name);
	    }

	    @When("^User enters email (.*)$")
	    public void user_enters_email(String email) {
	        psd.enter_email(email);
	    }

	    @When("^User enters fax (.*)$")
	    public void user_enters_fax(String fax) {
	        psd.enter_fax(fax);
	    }

	    @When("^User enters profile name (.*)$")
	    public void user_enters_profile_name(String profile_name) {
	        psd.enter_profileName(profile_name);
	    }

	    @When("User selects the option in Is Public Wishlist {string}")
	    public void user_selects_the_option_in_is_public_wishlist(String is_public_wishlist) {
	        psd.select_IsPublicWishlist(is_public_wishlist);
	    }

	    @When("User selects the option in Is Newsletter Subscription {string}")
	    public void user_selects_the_option_in_is_newsletter_subscription(String newsletter_subscription) {
	        psd.select_NewsletterSubscription(newsletter_subscription);
	    }

	    @When("User selects the option in Is Transmail Unsubscribe {string}")
	    public void user_selects_the_option_in_is_transmail_unsubscribe(String transmail_unsubscribe) {
	        psd.select_transmailUnsubscribe(transmail_unsubscribe);
	    }

	    @When("User selects the option in Is Promomail Unsubscribe {string}")
	    public void user_selects_the_option_in_is_promomail_unsubscribe(String promomail_unsubscribe) {
	        psd.select_promomailUnsubscribe(promomail_unsubscribe);
	    }
	    
	    @When("User selects the option in country code{string}")
	    public void user_selects_the_option_in_country_code(String countryCode) throws InterruptedException  {
	    psd.select_countryCode();
	    }


	    @When("^User enters mobile number (.*)$")
	    public void user_enters_mobile_number(String mobile_number) {
	        psd.enter_mobileNumber(mobile_number);
	    }

	    @When("User clicks on the I am not a robot checkbox")
	    public void user_clicks_on_the_i_am_not_a_robot_checkbox() {
	        psd.click_checkBox();
	    }

	    @When("User clicks on the Update button")
	    public void user_clicks_on_the_update_button() {
	        psd.click_updateButton();
	    }

	    @When("^User enters the email OTP (.*)$")
	    public void user_enters_the_email_otp(String OTP) {
	        psd.enter_OTP(OTP);
	    }

	    @When("User clicks on the Verify button")
	    public void user_clicks_on_the_verify_button() {
	        psd.verify_OTP();
	    }

	    @When("User clicks on the Update button again")
	    public void user_clicks_on_the_update_button_again() {
	        psd.click_updateButton();
	    }

	    @Then("User should be able to update the personal details successfully")
	    public void user_should_be_able_to_update_the_personal_details_successfully() {
	        // Placeholder for validation logic
	        // Example: Assert.assertEquals("Expected Message", actualMessage);
	        System.out.println("Personal details updated successfully.");
	    }
	}
