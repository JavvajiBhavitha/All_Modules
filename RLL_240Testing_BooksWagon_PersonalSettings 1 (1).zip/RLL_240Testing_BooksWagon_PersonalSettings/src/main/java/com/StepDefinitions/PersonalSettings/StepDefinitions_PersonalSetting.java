package com.StepDefinitions.PersonalSettings;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.HomePage;
import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.Login;
import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.PersonalSetting;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions_PersonalSetting {

	  WebDriver driver;
      HomePage hp;
      PersonalSetting ps; 
      Login ln;
      Logger log13;
      
  	@Before
  	public void init() {
  		driver = new ChromeDriver();
  		ps = new PersonalSetting(driver);
  		hp=new HomePage(driver);
  		ln =  new Login(driver);
  		log13 = Logger.getLogger(StepDefinitions_PersonalSetting.class);
  	}
	@Given("User is on login page")
   public void user_is_on_login_page() throws InterruptedException {
		//driver.get("https://www.bookswagon.com/");
		ps.launch();
		Thread.sleep(1000);
		ln.login("7660830781","Sravani@123");
		Thread.sleep(1000);

        driver.navigate().to("https://www.bookswagon.com/myaccount.aspx");
        Thread.sleep(5000);
  
//   driver = new ChromeDriver();
//		ps = new PersonalSetting(driver);
//		hp=new HomePage(driver);
//		ps.launch();
//   //log13.info("user is in login page");
    
   }
   @When("User clicks on Personal Settings")
   public void user_clicks_on_personal_settings() {
    ps.click_personalSettingsButton();
   
   }

   @Then("User should be able to click on Personal Settings option")
   public void user_should_be_able_to_click_on_personal_settings_option() {
//   	 String expected = "Personal Settings";
//   	    WebElement actualElement = driver.findElement(By.xpath("//*[contains(text(),\"Personal Settings\")]"));
//   	    String actualText = actualElement.getText();
   	    //Assert.assertEquals(actualText, expected);
   	   /* if (actualText.equals(expected)) {
   	        System.err.println("Personal Settings option is clickable and visible");
   	    } else {
   	        System.out.println("Personal Settings option is not clickable or visible");
   	    } */
   	   // System.out.println("click personal setting");
   }
}
 	    
 	   // Assert.assertEquals(actualText, expected);
 	   /* if (actualText.equals(expected)) {
 	        System.err.println("Personal Settings option is clickable and visible");
 	    } else {
 	        System.out.println("Personal Settings option is not clickable or visible");
 	    } 
 	    System.out.println("click personal setting");
 }
}
	*/
	

	 