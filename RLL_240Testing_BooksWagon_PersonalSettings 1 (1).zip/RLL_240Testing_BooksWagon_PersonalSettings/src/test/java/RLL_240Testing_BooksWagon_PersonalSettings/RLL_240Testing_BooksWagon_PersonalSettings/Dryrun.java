package RLL_240Testing_BooksWagon_PersonalSettings.RLL_240Testing_BooksWagon_PersonalSettings;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.HomePage;
import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.Login;
import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.PersonalSetting;
import com.pages.RLL_240Testing_BooksWagon_PersonalSettings.PersonalSettingDetails;

public class Dryrun {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver;
		driver= new ChromeDriver();
		
		HomePage hp = new HomePage(driver);
		PersonalSetting ps = new PersonalSetting(driver);
		PersonalSettingDetails psd = new PersonalSettingDetails(driver);
		
		hp.launch();
		Login ln = new Login(driver);
		
		hp.Click_MyAccount();
		Thread.sleep(1000);
		
		ln.launchBooksWagon();
		ln.login("7660830781", "Sravani@123");
//		ln.enter_emailfield("7660830781");
//		ln.enter_password("Sravani@123");
//		ln.click_submitButtton();
		
         ps.launch();
        // ps.click_myAccount();
         //ps.click_yourAccount();
		 ps.click_personalSettingsButton();
		
		    psd.launch();
			psd.enter_firstname("Sravani");
			psd.enter_lastname("Reddy");
			psd.enter_email("nimmasravani2001@gmail.com");
			psd.enter_fax("abc");
			psd.enter_profileName("Sravani");
			psd.select_IsPublicWishlist("No");
			psd.select_NewsletterSubscription("No");
			psd.select_promomailUnsubscribe("No");
			psd.select_transmailUnsubscribe("No");
			psd.select_countryCode();
			psd.enter_mobileNumber("7660830781");
			psd.click_checkBox();
			psd.click_updateButton();
			psd.enter_OTP("234567");
			psd.verify_OTP();
	}

}
